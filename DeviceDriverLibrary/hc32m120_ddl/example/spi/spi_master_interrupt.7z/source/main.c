/**
 *******************************************************************************
 * @file  spi/spi_master_interrupt/source/main.c
 * @brief Main program SPI master interrupt for the Device Driver Library.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2019-06-05       Wuze            First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2016, Huada Semiconductor Co., Ltd. All rights reserved.
 *
 * This software is owned and published by:
 * Huada Semiconductor Co., Ltd. ("HDSC").
 *
 * BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
 * BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
 *
 * This software contains source code for use with HDSC
 * components. This software is licensed by HDSC to be adapted only
 * for use in systems utilizing HDSC components. HDSC shall not be
 * responsible for misuse or illegal use of this software for devices not
 * supported herein. HDSC is providing this software "AS IS" and will
 * not be responsible for issues arising from incorrect user implementation
 * of the software.
 *
 * Disclaimer:
 * HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
 * REGARDING THE SOFTWARE (INCLUDING ANY ACCOMPANYING WRITTEN MATERIALS),
 * ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
 * WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
 * WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
 * WARRANTY OF NONINFRINGEMENT.
 * HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
 * NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
 * LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
 * LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
 * INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
 * SAVINGS OR PROFITS,
 * EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
 * INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
 * FROM, THE SOFTWARE.
 *
 * This software may be replicated in part or whole for the licensed use,
 * with the restriction that this Disclaimer and Copyright notice must be
 * included with each copy of this software, whether used in part or whole,
 * at all times.
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "hc32_ddl.h"

/**
 * @addtogroup HC32M120_DDL_Examples
 * @{
 */

/**
 * @addtogroup SPI_Master_Interrupt
 * @{
 */

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
/* SPI pin group definition. */
#define SPI_PIN_GROUP_A             (1u)
#define SPI_PIN_GROUP_B             (2u)
#define SPI_PIN_GROUP               (SPI_PIN_GROUP_B)

#if (SPI_PIN_GROUP == SPI_PIN_GROUP_A)
#define SPI_NSS_PORT                (GPIO_PORT_1)
#define SPI_NSS_PIN                 (GPIO_PIN_3)
#define SPI_SCK_PORT                (GPIO_PORT_1)
#define SPI_SCK_PIN                 (GPIO_PIN_4)
#define SPI_MOSI_PORT               (GPIO_PORT_1)
#define SPI_MOSI_PIN                (GPIO_PIN_1)
#define SPI_MISO_PORT               (GPIO_PORT_1)
#define SPI_MISO_PIN                (GPIO_PIN_2)
#elif (SPI_PIN_GROUP == SPI_PIN_GROUP_B)
#define SPI_NSS_PORT                (GPIO_PORT_2)
#define SPI_NSS_PIN                 (GPIO_PIN_2)
#define SPI_SCK_PORT                (GPIO_PORT_2)
#define SPI_SCK_PIN                 (GPIO_PIN_3)
#define SPI_MOSI_PORT               (GPIO_PORT_2)
#define SPI_MOSI_PIN                (GPIO_PIN_0)
#define SPI_MISO_PORT               (GPIO_PORT_2)
#define SPI_MISO_PIN                (GPIO_PIN_1)
#else
#error "SPI pin group not exists."
#endif // #if (SPI_PIN_GROUP == SPI_PIN_GROUP_A)

/* SPI wire mode definition. */
#define SPI_APP_3_WIRE              (3u)
#define SPI_APP_4_WIRE              (4u)
#define SPI_APP_X_WIRE              (SPI_APP_3_WIRE)

#if (SPI_APP_X_WIRE == SPI_APP_4_WIRE)
#define SPI_WIRE_MODE               (SPI_WIRE_4)
#else
#define SPI_WIRE_MODE               (SPI_WIRE_3)
#endif // #if (SPI_APP_X_WIRE == SPI_APP_4_WIRE)


/* SPI communication mode definition */
#define SPI_APP_SEND_ONLY           (1u)        /*!< Send only. */
#define SPI_APP_FULL_DUPLEX         (2u)        /*!< Send and receive. */
#define SPI_APP_TRANS_MODE          (SPI_APP_FULL_DUPLEX)

#if (SPI_APP_TRANS_MODE == SPI_APP_FULL_DUPLEX)
    #define SPI_TRANS_MODE          (SPI_FULL_DUPLEX)
#else
    #define SPI_TRANS_MODE          (SPI_SEND_ONLY)
#endif // #if (SPI_APP_TRANS_MODE == SPI_APP_FULL_DUPLEX)


/* SPI data buffer size definition. */
#define SPI_BUFFER_LENGTH           (6u)


/* Share interrupt definition. */
#define SHARE_INTERRUPT

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void SystemClockConfig(void);
static void SpiConfig(void);
static void SpiIrqConfig(void);

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of spi_master_interrupt project
 * @param  None
 * @retval int32_t return value, if needed
 */
int32_t main(void)
{
    uint8_t au8Data[SPI_BUFFER_LENGTH] = {0x50, 0x51, 0x52, 0x53, 0x54, 0x55};

    /* Configure the system clock to HRC32MHz. */
    SystemClockConfig();

    /* Configures SPI. */
    SpiConfig();

    /***************** Configuration end, application start **************/

    while (1u)
    {
        SPI_Transmit((uint8_t *)&au8Data[0u], SPI_BUFFER_LENGTH);
    }
}

/**
 * @brief  Configures a new system clock -- HRC32MHz.
 * @param  None
 * @retval None
 */
static void SystemClockConfig(void)
{
    /* Configure the system clock to HRC32MHz. */
    CLK_HRCInit(CLK_HRC_ON, CLK_HRCFREQ_32);
}

/**
 * @brief  SPI configuration, including initialization, pin configuration
 *         and interrupt configuration.
 * @param  None
 * @retval None
 */
static void SpiConfig(void)
{
    stc_spi_init_t stcInit;

    /* Set a default value. */
    SPI_StructInit(&stcInit);

    /* User configuration value. */
    stcInit.u32WireMode          = SPI_WIRE_MODE;
    stcInit.u32TransMode         = SPI_TRANS_MODE;
    stcInit.u32BaudRatePrescaler = SPI_BR_DIV_32;

    /* The SPI register can be written only after the SPI peripheral is enabled. */
    CLK_FcgPeriphClockCmd(CLK_FCG_SPI, Enable);

    /* Initializes SPI. */
    SPI_Init(&stcInit);

    /* Set the pins to SPI function. */
#if (SPI_APP_X_WIRE == SPI_APP_4_WIRE)
    GPIO_SetFunc(SPI_NSS_PORT, SPI_NSS_PIN, GPIO_FUNC_SPI);
#endif // #if (SPI_APP_X_WIRE == SPI_APP_4_WIRE)
    GPIO_SetFunc(SPI_SCK_PORT, SPI_SCK_PIN, GPIO_FUNC_SPI);
    GPIO_SetFunc(SPI_MOSI_PORT, SPI_MOSI_PIN, GPIO_FUNC_SPI);
    GPIO_SetFunc(SPI_MISO_PORT, SPI_MISO_PIN, GPIO_FUNC_SPI);

    /* SPI interrupt configuration. */
    SpiIrqConfig();

    /* Enable SPI function. */
    SPI_FunctionCmd(Enable);
}

/**
 * @brief  SPI interrupt configuration.
 * @param  None
 * @retval None
 * @note   All SPI interrupts can be configured as independent interrupt or shared interrupt.
 *         INT_SPI_SPEI: ERROR interrupt,
 *                       Independent vec[Int008_IRQn, Int009_IRQn]
 *                       Share vec [Int024_IRQn]
 *         INT_SPI_SPRI: RX buffer full interrupt,
 *                       Independent vec[Int014_IRQn, Int015_IRQn]
 *                       Share vec[Int027_IRQn]
 *         INT_SPI_SPII: IDLE interrupt,
 *                       Independent vec[Int016_IRQn, Int017_IRQn]
 *                       Share vec[Int028_IRQn]
 *         INT_SPI_SPTI: TX buffer empty interrupt,
 *                       Independent vec[Int022_IRQn, Int023_IRQn]
 *                       Share vec[Int031_IRQn]
 */
static void SpiIrqConfig(void)
{
    stc_irq_regi_config_t stcIrqRegiConf;

    /* Configures error interrupt.
       The following 2 configurations of interrupt are both valid. */

#ifdef SHARE_INTERRUPT
    /* Share interrupt. */
    stcIrqRegiConf.enIntSrc    = INT_SPI_SPEI;
    stcIrqRegiConf.enIRQn      = Int024_IRQn;
    INTC_ShareIrqCmd(stcIrqRegiConf.enIntSrc, Enable);
    NVIC_ClearPendingIRQ(stcIrqRegiConf.enIRQn);
    NVIC_SetPriority(stcIrqRegiConf.enIRQn, DDL_IRQ_PRIORITY_03);
    NVIC_EnableIRQ(stcIrqRegiConf.enIRQn);
#else
    /* Independent interrupt. */
    stcIrqRegiConf.enIntSrc    = INT_SPI_SPEI;
    stcIrqRegiConf.enIRQn      = Int008_IRQn;
    stcIrqRegiConf.pfnCallback = SpiErr_IrqHandler;
    INTC_IrqRegistration(&stcIrqRegiConf);
    NVIC_ClearPendingIRQ(stcIrqRegiConf.enIRQn);
    NVIC_SetPriority(stcIrqRegiConf.enIRQn, DDL_IRQ_PRIORITY_03);
    NVIC_EnableIRQ(stcIrqRegiConf.enIRQn);
#endif // #ifdef SHARE_INTERRUPT

    /* Enable the interrupt. */
    SPI_IntCmd(SPI_INT_ERROR, Enable);
}

/**
 * @brief  SPI error interrupt callback function.
 * @param  None
 * @retval None
 */
void SpiErr_IrqHandler(void)
{
    if (SPI_GetFlag(SPI_FLAG_OVERLOAD) == Set)
    {
        SPI_ClearFlag(SPI_FLAG_OVERLOAD);
    }

    if (SPI_GetFlag(SPI_FLAG_MODE_FAULT) == Set)
    {
        SPI_ClearFlag(SPI_FLAG_MODE_FAULT);
    }

    if (SPI_GetFlag(SPI_FLAG_PARITY_ERROR) == Set)
    {
        SPI_ClearFlag(SPI_FLAG_PARITY_ERROR);
    }

    if (SPI_GetFlag(SPI_FLAG_UNDERLOAD) == Set)
    {
        SPI_ClearFlag(SPI_FLAG_UNDERLOAD);
        SPI_FunctionCmd(Enable);
    }
}

/**
 * @}
 */

/**
 * @}
 */

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
