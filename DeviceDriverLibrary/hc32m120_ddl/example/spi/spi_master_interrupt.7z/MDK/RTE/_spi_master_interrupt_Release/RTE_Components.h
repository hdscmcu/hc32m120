
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'spi_master_interrupt' 
 * Target:  'spi_master_interrupt_Release' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "HC32M120J6TB.h"



#endif /* RTE_COMPONENTS_H */
